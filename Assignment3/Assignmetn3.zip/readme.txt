# Name: Rabib Husain
# ID: 1002053770

Task 1:
    kNN.py
    Usage in command line: python kNN.py
    As bonus is implemented the use will be asked a value of k and it will visualize the kNN for both distance metrics.

Task 2:
    MLChoice.py
    Usage in command line: python MLChoice.py <ML> <DataSet>
        ML: knn/svm
        Usage for iris DataSet: python MLChoice.py <ML> <iris>
        Usage for bank note DataSet: python MLChoice.py <ML> <banknote>
        Usage for breast cancer DataSet: python MLChoice.py <ML> <breast_cancer>

    The dataset for banknote is downloaded as data_banknote_authentication.txt and the other two datasets are imported
    As some of the datasets have many numerical features, for those only first 3 features is visualized in 3D which is pop up after the program is run from command line.
            